name = "Boris"
age = 27
handsome = True
favorite_language = "Python"

print(name)
print(handsome)
# print(occupation)

print(age + 4)
print("My name is", name, "and I am", age, "years old")

age = 23
print(age)

age = 27 + 10
print(age)

fact_or_fiction = 6 < 10
print(fact_or_fiction)

chameleon = 5
print(chameleon)

chameleon = "Some string"
print(chameleon)

chameleon = 9.99
print(chameleon)

chameleon = False
print(chameleon)