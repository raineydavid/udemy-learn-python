a = 5
b = 5

a = b = 5

b = 10
print(b)
print(a)

a = 5
b = 10

a, b = 5, 10

a, b, c = 5, 10, 13
print(a)
print(b)
print(c)