print(type(5))
print(type(10))

print(type(3.8))
print(type(5.0))

print(type("computer"))
print(type("laptop"))

print(type(5) == type(10))
print(type("computer") == type("laptop"))
print(type(5) == type(5.0))
print(type(5) == type("5"))

print(type(True))
print(type(False))
print(type(True) == type(False))

print(type([1, 2, 3]))
print(type({ "NJ": "Trenton" }))