print("\tTake a look. There's a tab and line break\n right here.")

print(r"\tTake a look. There's a tab and line break\n right here.")