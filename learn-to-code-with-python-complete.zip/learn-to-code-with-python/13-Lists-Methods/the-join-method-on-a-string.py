address = ["500 Fifth Avenue", "New York", "NY", "10036"]

print(",".join(address))
print(", ".join(address))
print("".join(address))

print("-".join(["555", "123", "4567"]))
print("|".join(["555", "123", "4567"]))
print("***".join(["555", "123", "4567"]))