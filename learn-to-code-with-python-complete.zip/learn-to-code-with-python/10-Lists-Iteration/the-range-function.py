# for number in range(11):
#     print(number)

# for number in range(3, 9):
#     print(number)

# for number in range(10, 101, 8):
#     print(number)

for number in range(99, -1, -11):
    print(number)