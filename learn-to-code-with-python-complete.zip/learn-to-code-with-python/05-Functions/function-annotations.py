def word_multiplier(word: str, times: int) -> str:
    return word * times

print(word_multiplier(10, 5))
