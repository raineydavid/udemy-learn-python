def divide_five_by_number(n):
    try:
        return 5 / n
    except:
        pass

print(divide_five_by_number(0))
print(divide_five_by_number(10))
print(divide_five_by_number("Nonsense"))