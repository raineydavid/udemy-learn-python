print("Good morning")
#print("Good afternoon")
print("Good night")

# This will perform a mathematical calculation
print(1 + 1) # Adds together 1 + 1

# print(1 + 1)
# print(1 + 1)
# print(1 + 1)