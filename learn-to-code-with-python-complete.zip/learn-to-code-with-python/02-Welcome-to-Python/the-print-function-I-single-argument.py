print("I love sandwiches")
print('I also love juice beverages')
print("We're working with Python")

print(5)
print(3 + 4)
print(10 - 8)

print("3 + 4")

print("3" + "4  ")