import calculator as calc
import datetime as dt

print(calc.add(3, 5))
print(dt.datetime(2020, 4, 12))