class Guitar():
    def __init__(self):
        print(f"A new guitar is being created! This object is {self}")

acoustic = Guitar()
print(acoustic)

electric = Guitar()
print(electric)