class Person():
    pass

class DatabaseConnection():
    pass

boris = Person()
sally = Person()

print(boris)
print(sally)

dc = DatabaseConnection()
print(dc)