print(not True)
print(not False)

if "H" in "Hello":
    print("That character exists in the string!")

if "Z" not in "Hello":
    print("That character does not exist in the string!")

value = 10

if value > 100:
    print("This will NOT print!")

if value < 100:
    print("This will print")

if not value > 100:
    print("This will print!")