if 3:
    print("Hello")

if -1:
    print("Goodbye")

if 0:
    print("Will this print?")

if "hello":
    print("La la la")

if "":
    print("This will not print")

print(bool(1))
print(bool(0))
print(bool(""))
print(bool("Python"))
print(bool(3.14))
print(bool(-1.309320))
print(bool(0.0))