print("programming"[3:6])

muscles = ["Biceps", "Triceps", "Deltoid", "Sartorius"]

print(muscles[1:3])
print(muscles[1:2])

print(muscles[0:2])
print(muscles[:2])
print(muscles[2:100])
print(muscles[2:])

print(muscles[-4:-2])
print(muscles[-3:])
print(muscles[:-1])
print(muscles[1:-1])

print(muscles[::2])
print(muscles[::-2])
print(muscles[::-1])