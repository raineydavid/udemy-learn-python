websites = {
    "Wikipedia": "http://www.wikipedia.org",
    "Google": "http://www.google.com",
    "Netflix": "http://www.netflix.com"
}

websites.clear()
print(websites)

del websites
# print(websites)