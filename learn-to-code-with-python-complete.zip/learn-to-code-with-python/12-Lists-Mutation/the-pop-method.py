action_stars = ["Norris", "Seagal", "Van Damme", "Schwarzenegger"]

# last_action_hero = action_stars.pop()
# print(action_stars)
# print(last_action_hero)

# action_stars.pop()
# print(action_stars)

# second_star = action_stars.pop(1)
# print(action_stars)
# print(second_star)

muscles_from_brussels = action_stars.pop(-2)
print(action_stars)
print(muscles_from_brussels)