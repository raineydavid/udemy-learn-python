vitamins = ["A", "D", "K"]
vitamins.reverse()
print(vitamins)