soups = ["French Onion", "Clam Chowder", "Chicken Noodle", "Miso", "Wonton"]

# del soups[1]

# del soups[-1]

del soups[1:3]
print(soups)