crayons = ["Macaroni and Cheese", "Maximum Yellow Red", "Jazzberry Jam"]
print(crayons)

crayons[1] = "Cotton Candy"
print(crayons)

crayons[0] = "Blizzard Blue"
print(crayons)

crayons[-1] = "Aquamarine"
print(crayons)

# crayons[3] = "Aztec Gold"